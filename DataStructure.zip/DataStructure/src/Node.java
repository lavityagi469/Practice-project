public class Node{
    public int parent_i;
    public int parent_j;
    public double f,g,h;
    

    public Node(int i, int j){
        this.parent_i = i;
        this.parent_j = j;
    }
}
