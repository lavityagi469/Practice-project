public class info{
    double f;
    int x;
    int y;

    public info(double f, int x, int y) {
        this.x = x;
        this.f = f;
        this.y = y;
    }

    public class Node{
        public int parent_i;
        public int parent_j;
        public double f,g,h;
        

        public Node(int i, int j){
            this.parent_i = i;
            this.parent_j = j;
        }
    }}