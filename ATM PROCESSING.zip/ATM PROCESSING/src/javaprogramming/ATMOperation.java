package javaprogramming;

public interface ATMOperation {
	public void viewBalance();
	public void withdrawAmount(double withdrawAmount);
	public void depositAmount(double depositamount);
	public void viewMiniStatement();
	

}
